#Copyright ReportLab Europe Ltd. 2000-2004
#see license.txt for license details
#history http://www.reportlab.co.uk/cgi-bin/viewcvs.cgi/public/reportlab/trunk/reportlab/graphics/__init__.py
__version__=''' $Id: __init__.py 2385 2004-06-17 15:26:05Z rgbecker $ '''